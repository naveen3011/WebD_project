import React , {useEffect , useState} from "react";

const Home = () => {

  const[userName, setuserName] = useState('');
  const [show, setShow] = useState(false);

  const  userHomePage = async() => {
    try {
      const res= await fetch('/getdata',{
        method:"GET",
        headers:{
          "Content-Type":"application/json"
        },
      });


      const data= await res.json();
      setuserName(data.fullname);
      setShow(true);

    } catch (error) {
      console.log(error);
    }
  }

useEffect(()=>{
  userHomePage();
},[]);

  return (
    <>
       
      <div className='homepage'>
      
        <p className='pt-5'>WELCOME</p>
        
        <h2>{show?`${userName}!! Welcome to the Assignment`:'This is the Assignment'}</h2>
        
      </div>
    </>
  );
};

export default Home;
