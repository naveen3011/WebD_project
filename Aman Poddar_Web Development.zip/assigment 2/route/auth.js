/** @format */
const jwt=require('jsonwebtoken');
const express = require("express");
// const User = require("../model/userSchema");
const bcrypt = require("bcryptjs");
const router = express.Router();
const authenticate = require("../middleware/authenticate");

require("../db/conn");
const User = require("../model/userSchema");
const e = require('express');


      


// Using async await
router.post("/register", async (req, res) => {
  const {fullname, email, dob , gender , password } = req.body;

  if (!fullname || !email || !dob || !gender || !password ) {
    return res.status(422).json({ error: "Please fill the fields properly " });
  }

  try {
    const response = await User.findOne({ email: email });
    if (response) {
      return res.status(422).json({ error: "Email already exist " });
    }

    const user = new User({
      fullname,
       email,
       dob ,
      gender ,
       password
    });

    const userRegister = await user.save();

    if (userRegister) {
      return res.status(201).json({ message: "user registered successfully" });
    } else {
      res.status(500).json({ error: "Failed to register" });
    }
  } catch (error) {
    console.log(error);
  }
});



module.exports = router;
