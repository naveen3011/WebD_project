//client

In client folder there are components folder inside the src folder which consists the components
of the webpage as Homepage , Navbar , Signup , and a Error page

//Signup page
By using the useState hooks we are taking the input value from the user and using fetch method we are sending
data to the backend using strigify in json format and it stores data to the database using the server link of mongoDB .

//Homepage
It is the root page of the website consist of only some text in it/

//navbar
we have created the navbar component so we don't have to add codes of navbar to everypage.

//errorpage
we have created the errorpage so that if user wanted to route somewhere it doesn't exist then
he get a errorpage.

//backend

//model-> userSchema
this file consist of the userschema we wanted on the database.

//route-> auth.js
it consist of the APIs we wanted on the website to connect.

//to start the frontend
Assignment 2 -> client
installing packages: "npm install" after that run the below command 
command:- "npm start"

I have used proxy to send data from frontend to backend

//to start the backend server
installing packages: "npm install" after that run the below command
command:- "nodemon app.js"/"node app.js"